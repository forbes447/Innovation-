# Tesla 

A Pen created on CodePen.

Original URL: [https://codepen.io/Pamela9910/pen/YPNvjPe](https://codepen.io/Pamela9910/pen/YPNvjPe).

